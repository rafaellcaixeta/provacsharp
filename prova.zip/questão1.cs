/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;

class Program
{
    static void Main()
    {


        Console.WriteLine("digite um valor inteiro:");
        int valor = int.Parse(Console.ReadLine());
        int valorOriginal = valor;
        int[] notas = { 100, 50, 20, 10, 5, 2, 1 };

        foreach (int nota in notas)
        {
            int quantidadenota = valor / nota;
            valor %= nota;

            Console.WriteLine($"{quantidadenota} nota(s) de R$ {nota},00");
        }
    }
}