/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite uma data (dd/MM/yyyy):");
        string data1Input = Console.ReadLine();
        Console.WriteLine("Digite outra data (dd/MM/yyyy):");
        string data2Input = Console.ReadLine();

        if (DateTime.TryParseExact(data1Input, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime data1) &&
            DateTime.TryParseExact(data2Input, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateTime data2))
        {
            TimeSpan diferenca = data2 - data1;
            int diasEntreDatas = Math.Abs(diferenca.Days);

            Console.WriteLine($"A quantidade de dias entre {data1:dd/MM/yyyy} e {data2:dd/MM/yyyy} é: {diasEntreDatas} dias.");
        }
    }
}